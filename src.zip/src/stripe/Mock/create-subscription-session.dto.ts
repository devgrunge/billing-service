export class CreateSubscriptionSessionDto {
  priceId: string;
}